### R code from vignette source 'FlowSOM.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: style-Sweave
###################################################
BiocStyle::latex()


###################################################
### code chunk number 2: FlowSOM.Rnw:59-75
###################################################
set.seed(42)
library(FlowSOM)

fileName <- system.file("extdata","lymphocytes.fcs",
                        package="FlowSOM")
fSOM <- FlowSOM(fileName,
                # Input options:
                compensate = TRUE,transform = TRUE,toTransform=c(8:18),
                scale = TRUE,
                # SOM options:
                colsToUse = c(9,12,14:18), xdim = 7, ydim = 7,
                # Metaclustering options:
                nClus = 10)

PlotStars(fSOM[[1]],
            backgroundValues = as.factor(fSOM[[2]]))


###################################################
### code chunk number 3: FlowSOM.Rnw:108-119
###################################################
set.seed(42)
library(flowCore)
library(FlowSOM)

fileName <- system.file("extdata","lymphocytes.fcs",
                        package="FlowSOM")
fSOM <- ReadInput(fileName,compensate = TRUE,transform = TRUE, 
                    toTransform=c(8:18),scale = TRUE)

ff <- suppressWarnings(flowCore::read.FCS(fileName))
fSOM <- ReadInput(ff,compensate = TRUE,transform = TRUE, scale = TRUE)


###################################################
### code chunk number 4: FlowSOM.Rnw:130-131
###################################################
str(fSOM,max.level = 2)


###################################################
### code chunk number 5: FlowSOM.Rnw:149-151
###################################################
fSOM <- BuildSOM(fSOM,colsToUse = c(9,12,14:18))
str(fSOM$map,max.level = 2)


###################################################
### code chunk number 6: FlowSOM.Rnw:161-163
###################################################
fSOM <- BuildMST(fSOM,tSNE=TRUE)
str(fSOM$MST)


###################################################
### code chunk number 7: FlowSOM.Rnw:171-172
###################################################
PlotStars(fSOM)


###################################################
### code chunk number 8: FlowSOM.Rnw:174-175
###################################################
PlotStars(fSOM,view="grid")


###################################################
### code chunk number 9: FlowSOM.Rnw:177-178
###################################################
PlotStars(fSOM,view="tSNE")


###################################################
### code chunk number 10: FlowSOM.Rnw:184-188
###################################################
fSOM <- UpdateNodeSize(fSOM, reset=TRUE)
fSOM$MST$size <- fSOM$MST$size/2
PlotStars(fSOM)
fSOM <- UpdateNodeSize(fSOM)


###################################################
### code chunk number 11: FlowSOM.Rnw:195-210
###################################################
library(flowUtils)
flowEnv <- new.env()
ff_c <- compensate(ff,description(ff)$SPILL)
colnames(ff_c)[8:18] <- paste("Comp-",colnames(ff_c)[8:18],sep="")
gatingFile <- system.file("extdata","manualGating.xml", 
                        package="FlowSOM")
gateIDs <- c( "B cells"=8,
                "ab T cells"=10,
                "yd T cells"=15,
                "NK cells"=5,
                "NKT cells"=6)
cellTypes <- names(gateIDs)
gatingResult <- ProcessGatingML(ff_c, gatingFile, gateIDs, cellTypes)

PlotPies(fSOM,cellTypes=gatingResult$manual)


###################################################
### code chunk number 12: FlowSOM.Rnw:216-218
###################################################
print(colnames(fSOM$map$medianValues))
PlotMarker(fSOM,"Pacific Blue-A")


###################################################
### code chunk number 13: FlowSOM.Rnw:222-223
###################################################
PlotNumbers(UpdateNodeSize(fSOM,reset=TRUE))


###################################################
### code chunk number 14: FlowSOM.Rnw:227-228
###################################################
PlotClusters2D(fSOM,"PE-Texas Red-A","Pacific Blue-A",c(81,82,91,92,93))


###################################################
### code chunk number 15: FlowSOM.Rnw:241-244
###################################################
metaClustering <- metaClustering_consensus(fSOM$map$codes,k=7)
PlotPies(fSOM,cellTypes=gatingResult$manual,
        backgroundValues = as.factor(metaClustering))


###################################################
### code chunk number 16: FlowSOM.Rnw:248-249
###################################################
metaClustering_perCell <- metaClustering[fSOM$map$mapping[,1]]


###################################################
### code chunk number 17: FlowSOM.Rnw:259-271
###################################################
# Look for CD8+ ab T cells
query <- c("PE-Cy7-A" = "high", #CD3
            "APC-Cy7-A" = "high", #TCRb
            "Pacific Blue-A" = "high") #CD8
query_res <- QueryStarPlot(UpdateNodeSize(fSOM,reset=TRUE), query, 
                            plot = FALSE)

cellTypes <- factor(rep("Unknown",49),levels=c("Unknown","CD8 T cells"))
cellTypes[query_res$selected] <- "CD8 T cells"
PlotStars(fSOM,
            backgroundValues=cellTypes,
            backgroundColor=c("#FFFFFF00","#0000FF22"))


###################################################
### code chunk number 18: FlowSOM.Rnw:286-287
###################################################
sessionInfo()


