### R code from vignette source 'vignette.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: vignette.Rnw:63-74
###################################################
set.seed(42)
library(flowCore)
library(FlowSOM)

fileName <- system.file("extdata","lymphocytes.fcs",
                        package="FlowSOM")
fSOM <- ReadInput(fileName,compensate = T,transform = T, 
                  toTransform=c(8:18),scale = T)

ff <- read.FCS(fileName)
fSOM <- ReadInput(ff,compensate = T,transform = T, scale = T)


###################################################
### code chunk number 2: vignette.Rnw:81-82
###################################################
str(fSOM)


###################################################
### code chunk number 3: vignette.Rnw:93-95
###################################################
fSOM <- BuildSOM(fSOM,colsToUse = c(9,12,14:18))
str(fSOM$map)


###################################################
### code chunk number 4: vignette.Rnw:106-108
###################################################
fSOM <- BuildMST(fSOM)
str(fSOM$MST)


###################################################
### code chunk number 5: vignette.Rnw:114-115
###################################################
PlotStars(fSOM)


###################################################
### code chunk number 6: vignette.Rnw:119-122
###################################################
fSOM <- UpdateNodeSize(fSOM, reset=T)
PlotStars(fSOM,MST=F)
fSOM <- UpdateNodeSize(fSOM)


###################################################
### code chunk number 7: vignette.Rnw:126-155
###################################################
library(flowUtils)
flowEnv <- new.env()
ff_c <- compensate(ff,ff@description$SPILL)
colnames(ff_c)[8:18] <- paste("Comp-",colnames(ff_c)[8:18],sep="")
gatingFile <- system.file("extdata","manualGating.xml", 
                          package="FlowSOM")
read.gatingML(gatingFile, flowEnv) 
filterList <- list( "B cells" = flowEnv$ID52300206,
                    "ab T cells" = flowEnv$ID785879196,
                    "yd T cells" = flowEnv$ID188379411,
                    "NK cells" = flowEnv$ID1229333490,
                    "NKT cells" = flowEnv$ID275096433
                  )

results <- list()
for(cellType in names(filterList)){
  results[[cellType]] <- filter(ff_c,filterList[[cellType]])@subSet
}

manual <- rep("Unknown",nrow(ff))
for(celltype in names(results)){
  manual[results[[celltype]]] <- celltype
}
# Use a factor to define order of the cell types
manual <- factor(manual,levels = c("Unknown","B cells",
                                   "ab T cells","yd T cells", 
                                   "NK cells","NKT cells"))

PlotPies(fSOM,cellTypes=manual)


###################################################
### code chunk number 8: vignette.Rnw:166-168
###################################################
metaClustering <- metaClustering_consensus(fSOM$map$codes,k=7)
PlotPies(fSOM,cellTypes=manual,clusters = metaClustering)


###################################################
### code chunk number 9: vignette.Rnw:172-173
###################################################
metaClustering_perCell <- metaClustering[fSOM$map$mapping[,1]]


